/* _error.h
 *
 * This file sets up macros for returning integer error signals and 
 * for printing out the error to a stream.   Five types of errors are 
 * supported, and four error levels are defined.
 *
 * The error facilites are designed to work with K&R C, ANSII standard C 
 * and C++.
 *
 * William E. Hart
 * whart@cs.ucsd.edu
 *
 * Thu Oct 15 12:40:31 PDT 1992
 *
 * For code that is ultimately compiled with C++, the message handlers
 * in errmsg.h are more convenient.
 *
 */

/* If the errmsg.h file is being used, then do not use _error.h */
#ifndef __errmsg_h

#ifndef __error_h
#define __error_h

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#ifdef __cplusplus
#include <iostream.h>
#endif

/*
    Constants for different levels of error signals
*/

#ifndef OK
#define OK		(0)
#endif
#ifndef ERR
#define ERR             (-999)
#endif
#ifndef EXIT
#define EXIT            (-1000)
#endif
#ifndef BREAK
#define BREAK           (-1001)
#endif
#ifndef WARNING
#define WARNING         (-1002)
#endif
#ifndef ABORT
#define ABORT		(-1003)
#endif


/*
   Setup  Levels of Errors
  
   There are 6 types of errors:  MSG_NULL, MSG_PRT, MSG_RTN, MSG_PRT_RTN, 
  				MSG_PRT_EXIT MSG_PRT_ABRT
   There are 4 error levels
*/

#define GENERIC_LVL	MSG_PRT_RTN
#define WARNING_LVL	MSG_PRT
#define ERROR_LVL	MSG_PRT_RTN
#define EXIT_LVL	MSG_PRT_EXIT
#define ABORT_LVL	MSG_PRT_ABRT


/***

   Macros which are used by the programmer 

 ***/

#ifdef __cplusplus
#define Err_Init(x)			MsgType	ERR_MSG = MsgType((x),&cerr)
#else
#define Err_Init(x)			MsgType ERR_MSG = {x, stderr}
#endif

#define Msgreturn( err, msg )		MsgEval(GENERIC_LVL,err,msg)
#define Msgreturn1( err, msg, x )	MsgEval1(GENERIC_LVL,err,msg,x)
#define Msgreturn2( err, msg, x,y )	MsgEval2(GENERIC_LVL,err,msg,x,y)
#define Msgreturn3( err, msg, x,y,z )	MsgEval3(GENERIC_LVL,err,msg,x,y,z)
#define Msgreturn4( err, msg, w,x,y,z )	MsgEval4(GENERIC_LVL,err,msg,w,x,y,z)

#define Erreturn( msg )			MsgEval(ERROR_LVL,ERR,msg)
#define Erreturn1( msg, x )		MsgEval1(ERROR_LVL,ERR,msg,x)
#define Erreturn2( msg, x, y )		MsgEval2(ERROR_LVL,ERR,msg,x,y)
#define Erreturn3( msg, x, y, z )	MsgEval3(ERROR_LVL,ERR,msg,x,y,z)
#define Erreturn4( msg, w, x, y, z )	MsgEval4(ERROR_LVL,ERR,msg,w,x,y,z)

#define Warning( msg )			MsgEval(WARNING_LVL,WARNING,msg)
#define Warning1( msg, x )		MsgEval1(WARNING_LVL,WARNING,msg,x)
#define Warning2( msg, x, y )		MsgEval2(WARNING_LVL,WARNING,msg,x,y)
#define Warning3( msg, x, y, z )	MsgEval3(WARNING_LVL,WARNING,msg,x,y,z)
#define Warning4( msg, w, x, y, z )	MsgEval4(WARNING_LVL,WARNING,msg,w,x,y,z)

#define Erabort( msg )			MsgEval(ABORT_LVL,ABORT,msg)
#define Erabort1( msg, x )		MsgEval1(ABORT_LVL,ABORT,msg,x)
#define Erabort2( msg, x, y )		MsgEval2(ABORT_LVL,ABORT,msg,x,y)
#define Erabort3( msg, x, y, z )	MsgEval3(ABORT_LVL,ABORT,msg,x,y,z)
#define Erabort4( msg, w, x, y, z )	MsgEval4(ABORT_LVL,ABORT,msg,w,x,y,z)

#define Erexit( msg )			MsgEval(EXIT_LVL,EXIT,msg)
#define Erexit1( msg, x )		MsgEval1(EXIT_LVL,EXIT,msg,x)
#define Erexit2( msg, x, y )		MsgEval2(EXIT_LVL,EXIT,msg,x,y)
#define Erexit3( msg, x, y, z )		MsgEval3(EXIT_LVL,EXIT,msg,x,y,z)
#define Erexit4( msg, w, x, y, z )	MsgEval4(EXIT_LVL,EXIT,msg,w,x,y,z)




/*
   Setup the mechanics of the error handler
*/

#define Lmsg 256	/* Length of msg;  error msg can be fairly long */
#define Lhdr 64		/* Length of header */

#ifdef __cplusplus
struct MsgType{
	char		msg_header[Lhdr];
	ostream*	os;
	char		ERR_STR[Lmsg];
	MsgType()	{strcpy(msg_header,"\n"); os = &cerr; }
	MsgType(const char* str)
			{strcpy(msg_header,str); os=&cerr;}
	MsgType(const char* str, ostream* os_)
			{strcpy(msg_header,str); os=os_; }
	};

#define MsgPrint()	\
	*(ERR_MSG.os) << ERR_MSG.msg_header << " " << ERR_MSG.ERR_STR << "\n"; \
	(ERR_MSG.os)->flush();

#else
typedef struct {
	char		msg_header[Lhdr];
	FILE*		os;
	char		ERR_STR[Lmsg];
	} MsgType;

#define MsgPrint()	\
	fprintf(ERR_MSG.os, "%s %s\n", ERR_MSG.msg_header, ERR_MSG.ERR_STR); \
	fflush(ERR_MSG.os);
#endif


/*
 * Note:  the MsgEval definitions utilize the / ** / hack to concatenate
 *	tokens in non-ansii C preprocessors.  This does not work for ansii
 *	preprocessors, for which the ## operator should be used.
 */
#define MsgEval( err_lvl,err,msg )	  {strcpy(ERR_MSG.ERR_STR, msg); \
						err_lvl/**/(err) }
#define MsgEval1(err_lvl,err,msg,x)       {sprintf(ERR_MSG.ERR_STR,msg,x); \
						err_lvl/**/(err) }
#define MsgEval2(err_lvl,err,msg,x,y)     {sprintf(ERR_MSG.ERR_STR,msg,x,y); \
						err_lvl/**/(err) }
#define MsgEval3(err_lvl,err,msg,x,y,z)   {sprintf(ERR_MSG.ERR_STR,msg,x,y,z); \
						err_lvl/**/(err) }
#define MsgEval4(err_lvl,err,msg,w,x,y,z) {sprintf(ERR_MSG.ERR_STR,msg,w,x,y,z); \
					 	err_lvl/**/(err) }

#define MSG_NULL(x)		{}
#define MSG_PRT(x)		MsgPrint();
#define MSG_RTN(x)		return(x);
#define MSG_PRT_RTN(x)		MsgPrint(); return(x);
#define MSG_PRT_EXIT(x)		MsgPrint(); exit(x);
#define MSG_PRT_ABRT(x)		MsgPrint(); abort();

#ifdef ERR_BUF
static Err_Init(ERR_BUF);
#endif

#endif

#endif
