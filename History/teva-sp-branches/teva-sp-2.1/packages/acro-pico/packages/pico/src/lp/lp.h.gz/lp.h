/*  _________________________________________________________________________
 *
 *  PICO: A C++ library of scalable branch-and-bound and related methods.
 *  Copyright (c) 2001, Sandia National Laboratories.
 *  This software is distributed under the GNU Lesser General Public License.
 *  For more information, see the README file in the top PICO directory.
 *  _________________________________________________________________________
 */
#ifndef pico_lp_h
#define pico_lp_h

#define USING_LP

#if defined(USING_CPLEX)
#include "cplexLP.h"
#define LP cplexLP

#elif defined(USING_CPLEX5)
#include "cplexLP5.h"
#define LP cplexLP5

#elif defined(USING_XPRESS)
#include "xpressLP.h"
#define LP xpressLP

#elif defined(USING_SOPLEX)
#include "soplexLP.h"
#define LP soplexLP

#else
#define LP genericLP
#undef USING_LP
#endif

#endif
