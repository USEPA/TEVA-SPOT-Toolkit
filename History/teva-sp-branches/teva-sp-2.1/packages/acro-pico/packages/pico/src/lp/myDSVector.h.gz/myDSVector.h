/*  _________________________________________________________________________
 *
 *  PICO: A C++ library of scalable branch-and-bound and related methods.
 *  Copyright (c) 2001, Sandia National Laboratories.
 *  This software is distributed under the GNU Lesser General Public License.
 *  For more information, see the README file in the top PICO directory.
 *  _________________________________________________________________________
 */

#ifndef pico_myDSVector_h
#define pico_myDSVector_h

#ifdef USING_SOPLEX

#include "dsvector.h"

namespace pico {

class myDSVector: public soplex::DSVector
{
public:
  myDSVector(int length, int *indices, double *elements)
    : soplex::DSVector(length)
  {
    Element *e = elem;
    
    size() = length;

    while(length--)
    {
      e->val = *elements;
      e->idx = *indices;
      e++;
      elements++;
      indices++;
    }

    assert(isConsistent());
  }

};

} // namespace pico

#endif

#endif
