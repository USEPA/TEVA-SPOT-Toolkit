/*  _________________________________________________________________________
 *
 *  PICO: A C++ library of scalable branch-and-bound and related methods.
 *  Copyright (c) 2001, Sandia National Laboratories.
 *  This software is distributed under the GNU Lesser General Public License.
 *  For more information, see the README file in the top PICO directory.
 *  _________________________________________________________________________
 */
//
// PicoCuts.h
//
// A dummy file that Cindy will fill in later.
//

#ifndef pico_PicoCuts_h
#define pico_PicoCuts_h

#include <pico/OsiCuts.hpp>

namespace pico {

class PicoCuts : public OsiCuts
{
};

} // namespace pico

#endif
