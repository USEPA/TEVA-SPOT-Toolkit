TEVA-SPOT Toolkit README
========================

The Threat Ensemble Vulnerability Assessment and Sensor
Placement Optimization Tool (TEVA-SPOT) has been developed by the
U. S. Environmental Protection Agency, Sandia National Laboratories,
Argonne National Laboratory, and the University of Cincinnati.  TEVA-SPOT
allows a user to specify a wide range of modeling inputs and performance
objectives for contamination warning system design. Further, TEVA-SPOT
supports a flexible decision framework for sensor placement that involves
two major steps: a modeling process and a decision-making process [12].
The modeling process includes (1) describing sensor characteristics,
(2) defining the design basis threat, (3) selecting impact measures
for the CWS, (4) planning utility response to sensor detection, and (5)
identifying feasible sensor locations.

The capabilities of TEVA-SPOT can be accessed either with a GUI or from
command-line tools. This software is the TEVA-SPOT Toolkit, which contains
these command-line tools. The TEVA-SPOT Toolkit can be used within either
a MS Windows DOS shell or any standard Unix shell (e.g. the Bash shell).


INSTALLATION
============

The TEVA-SPOT Toolkit can be installed on MS Windows with an
an installer that installs the software in the C:\spot directory.
See the TEVA-SPOT Toolkit User Manual for further details.


GETTING STARTED
===============

The TEVA-SPOT Toolkit User Manual (doc\uguide\userman.pdf) provides a
detailed description of the command-line tools in the TEVA-SPOT Toolkit.
The examples used in this manual can be accessed in the examples\simple
directory.


TEVA-SPOT Toolkit Bug Tracking
==============================

https://software.sandia.gov/trac/spot


SUPPORT
=======

1. Authors

   See the AUTHORS file.

2. Project Managers

   Regan Murray, US Environmental Protection Agency
   William E. Hart, Sandia National Laboratories

3. Mailing List

   None

4. Bug Reports

   See the Trac project page: https://software.sandia.gov/trac/spot

